package com.example.controle.dao.repositories;

import com.example.controle.dao.entities.Car;
import org.springframework.data.jpa.repository.JpaRepository;


import java.util.List;

public interface CarRepository extends JpaRepository<Car,Long> {
    public boolean existsByMatricul(String matricul);
    public List<Car>findByModel(String Model);
    public List<Car>findByModelAndPrice(String Model,Float price);

}
